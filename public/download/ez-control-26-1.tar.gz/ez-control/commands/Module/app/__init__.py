
__data__ = {
    "name" : "ez control",
    "version" : "26.1"
}
